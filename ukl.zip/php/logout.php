<?php
session_start();
session_destroy();
?>
<script type="text/javascript">
    alert('selamat, anda berhasil log out.');
    location.href = "1";