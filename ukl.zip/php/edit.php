<?php
include 'config.php'; // Pastikan file koneksi database sudah benar

// Cek apakah ada ID yang dikirim melalui URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    // Debug: Cek apakah ID yang diterima benar
    echo "<p>DEBUG: ID yang diterima = $id</p>";

    // Cek apakah form disubmit
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
   
    //  Ambil data dari form dengan validasi
    $ID = isset($_POST['id_user']) ? $_POST['id_user'] : '';
    $nama = isset($_POST['nama']) ? $_POST['nama'] : '';
    $tanggal_lahir = isset($_POST['tanggal_lahir']) ? $_POST['tanggal_lahir'] : '';
    $no_handphone = isset($_POST['no_handphone']) ? $_POST['no_handphone'] : '';
    $email = isset ($_POST['email'])? $_POST['email'] : '';
    $pass = isset($_POST['password']) ? $_POST['password'] : '';
    
    // Periksa apakah semua variabel ada sebelum update
    if (!empty($nama) && !empty($tanggal_lahir) && !empty($no_handphone) && !empty($email) && !empty($pass)) {
        // Query UPDATE
        $sql = "UPDATE userweb SET 
                    nama = '$nama', 
                    tanggal_lahir = '$tanggal_lahir',
                    no_handphone = '$no_handphone',
                    email = '$email',
                    password = '$pass'
                WHERE id_user = '$id'";

        // Jalankan query
        if (mysqli_query($conn, $sql)) {
            echo "<script>alert('Data berhasil diperbarui!'); window.location.href='index.php';</script>";
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    } else {
        echo "Error: Ada data yang kosong. Pastikan semua field terisi!";
    }
}


    // Query untuk mengambil data user berdasarkan ID
    $sql = "SELECT * FROM userweb WHERE id_user = '$id'";
    $result = mysqli_query($conn, $sql);

    // Debug: Cek apakah query berhasil
    if (!$result) {
        die("Query error: " . mysqli_error($conn));
    }

    // Debug: Cek apakah ada data yang ditemukan
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
    } else {
        die("Error: Data pengguna tidak ditemukan di database!");
    }
} else {
    die("Error: ID tidak valid atau tidak diberikan!");
}
?>

<h2>Edit Pengguna</h2>

<form method="post">
    <input type="hidden" name="id_user" value="<?php echo isset($row['id_user']) ? htmlspecialchars($row['id_user']) : ''; ?>">
    Nama: <input type="text" name="nama" value="<?php echo isset($row['nama']) ? htmlspecialchars($row['nama']) : ''; ?>" required><br><br>
    tanggal_lahir: <input type="date" name="tanggal_lahir" value="<?php echo isset($row['tanggal_lahir'])?htmlspecialchars($row['tanggal_lahir']) : '';?>"><br><br>
    no_handphone: <input type="text" name="no_handphone" value="<?php echo isset($row['no_handphone']) ? htmlspecialchars($row['no_handphone']) : ''; ?>" required><br><br>
    Email: <input type="email" name="email" value="<?php echo isset($row['email']) ? htmlspecialchars($row['email']) : ''; ?>" required><br><br>
    Password: <input type="password" name="password" value="<?php echo isset($row['password']) ? htmlspecialchars($row['password']) : ''; ?>" required><br><br>
    <input type="submit" value="Update">
</form>

<a href="index.php">Kembali</a>