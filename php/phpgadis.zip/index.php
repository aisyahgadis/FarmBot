<?php
include 'config.php';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Pengguna</title>
    <style>
        table{
            width: 50%;
            border-collapse: collapse;
            margin: 20px;
        }
        th, td {
            border: 1px solid black;
            padding 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>
    <h2>Daftar Pengguna</h2>
    <a href="daftar.php">Tambah Data</a>

    <table border="1">
        <tr>
            <th>Id</th>
            <th>Nama</th>
            <th>Tanggal Lahir</th>
            <th>No Handphone</th>
            <th>Email</th>
            <th>Password</th>
            <th>Aksi</th>
        </tr>

        <?php
     // **3. Query Data dari Tabel `userweb`**
        $sql = "SELECT * FROM userweb";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                    <td>{$row['id']}</td>
                    <td>{$row['name']}</td>
                    <td>{$row['tanggal_lahir']}</td>
                    <td>{$row['no_handphone']}</td>
                    <td>{$row['email']}</td>
                    <td>{$row['password']}</td>
                    <td>
                        <a href='edit.php?id={$row['id']}'>Edit</a> |
                        <a href='delete.php?id={$row['id']}' onclick='return confirm(\"Hapus Data ini?\")'>Hapus</a>
                    </td>
                </tr>";
            }
        } else {
            echo "<tr><td colspan='7'>Tidak ada data</td></tr>";
        }

        // **4. Tutup Koneksi**
        $conn->close();
        ?>
    </table>
</body>
</html>
