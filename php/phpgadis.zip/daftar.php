<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    //Ambil data dari form
    $nama = $_POST['nama'];
    $tanggal_lahir = $_POST['tanggal_lahir'];
    $no_handphone = $_POST['no_handphone'];
    $email = $_POST['email'];
    $password = password_hash ($_POST['password'], PASSWORD_DEFAULT);
    $sql = "INSERT INTO userweb (name, tanggal_lahir, no_handphone, email, password) 
    VALUES ('$name', '$tanggal_lahir', '$no_handphone', '$email', '$password');";
    
    if ($conn->query($sql) === TRUE) {
        header("Location: index.php");
        exit();
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Pengguna</title>
</head>
<body>
   <h2> Tambah Pengguna</h2>
   <form method="post">
        Nama: <input type="text" name="name" required><br><br>
        Tanggal Lahir: <input type="date" name="dob" required><br><br>
        No Hp: <input type="phone" name="phone" required><br><br> 
        Email: <input type="text" name="name" required><br><br>
        Password: <input type="password" name="password" required><br><br>
        <input type= "submit" value="simpan">
    </form> 
    <a href="index.php">Kembali</a>
</body>
</html>