<?php
// $session_start to login or daftar
include "config.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login ke web</title>
</head>
<body>
<?php
session_start();
include "config.php"; // Pastikan file koneksi ke database sudah benar

if (isset($_POST['username'])) {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = $_POST['password']; // Tidak dienkripsi dulu karena akan diverifikasi

    // Query untuk mencari user berdasarkan username
    $query = mysqli_query($conn, "SELECT * FROM user WHERE username='$username'");

    if ($query && mysqli_num_rows($query) > 0) {
        $data = mysqli_fetch_array($query);

        // Verifikasi password menggunakan password_verify()
        if (password_verify($password, $data['password'])) {
            $_SESSION['user'] = $data;
            echo '<script>alert("Selamat datang, ' . $data['nama'] . '"); location.href="index.php";</script>';
        } else {
            echo '<script>alert("Username/password tidak sesuai.");</script>';
        }
    } else {
        echo '<script>alert("Username/password tidak sesuai.");</script>';
    }
}
?>
    <form method="post">
        <table align="center">
            <tr>
                <td colspan="2" align="center">
                    <h3>Login User</h3>
                </td>
            </tr>
            <tr>
                <td>Username</td>
                <td><input type="text" name="username"></td>
            </tr>
            <tr>
                <td>Password</td>
                <td><input type="password" name="password"></td>
            </tr>
            <tr>
                <td></td>
                <td>
                    <button type="submit">Login</button>
                    <a href="daftar.php">Daftar</a>
                </td>
            </tr>
        </table>
    </form>
</body>
</html>